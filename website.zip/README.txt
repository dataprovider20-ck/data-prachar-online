DATA PRACHAR ONLINE WEBSITE

1. Upload everything in this folder to your GitHub repository (keep the folders: admin, images).
2. GitHub: Settings > Pages > Deploy from branch > main > / (root).
3. In admin/config.yml change YOUR-REPO-NAME to your repository name.
4. In sitemap.xml and robots.txt replace YOUR-SITE-URL with your website address (for example dataprovider20-ck.github.io/your-repo).
5. Open your-site/admin/ to edit content with the CMS.
6. Fill in one test enquiry form, then click the confirmation link FormSubmit emails to chandrakar40@gmail.com.
